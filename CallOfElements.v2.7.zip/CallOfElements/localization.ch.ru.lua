-- Version : Russian ( by Maus )

if ( GetLocale() == "ruRU" ) then

-- Chat Configuration
SCHEDULE_COMM		= {"/in","/pause","/delay"};
SCHEDULE_DESC		= "/in <сек> <команда> [<арг> ...] |cFFCC9966[Примечание: /in НЕЛЬЗЯ применять заклинания, чтобы предотвратить создание бота]|r";
SCHEDULE_USAGE1		= "Использование: /in <сек> <команда> [<арг> ...]";
SCHEDULE_USAGE2		= "Запуск <команда> с аргументами <арг> после <сек> сек.";

end