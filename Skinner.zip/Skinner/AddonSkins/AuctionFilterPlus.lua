
function Skinner:AuctionFilterPlus()

	self:keepRegions(afp_FlyoutFrame, {10,11,12,13,14,15,16,17,18})
	self:applySkin(afp_FlyoutFrame, nil)

end
