
function Skinner:GCInfo()

	self:applySkin(_G["GCInfoFrame"])
	
end
