function Skinner:MonkeyQuestLog()
	self:applySkin(_G["MkQL_Main_Frame"])
end
