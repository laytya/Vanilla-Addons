
function Skinner:PVPCooldown()

	self:applySkin(_G["PVPCooldownFrame"])
	
end
