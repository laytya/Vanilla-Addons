
function Skinner:MyBags()

	self:applySkin(_G["MyBankFrame"])
	self:applySkin(_G["MyInventoryFrame"])
	
end
