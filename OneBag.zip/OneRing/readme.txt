[b]Current Version: 2.0.$Revision: 12749 $[/b] 
 
[SIZE=3][b]OneRing[/b][/SIZE]

[b]Description:[/b]
OneRing is a replacement for the keyring that brings it in line graphically with the rest of the OneBag suite.  Its a compainion for OneBag.

[b]Features:[/b][list]
[*]Makes the keyring look like the rest of the OneBag suite.
[/list]
 
[b]A Couple of Notes:[/b][list]
[*]This mod does rely on the Ace2 embedable framework.  Ace2 is the next generation of the Ace line, and does not require an external Ace2 addon as a dependency.  
[*]However, OneBag is a required dependency for OneRing.  Much of the code between the two is different and as such only exists within the OneBag files.
[/list]

[SIZE=3][b][url=http://kaelten.wowinterface.com/portal.php?&id=2&pageid=73]Version History[/url][/b][/SIZE]