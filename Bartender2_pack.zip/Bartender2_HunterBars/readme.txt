Bartender2_HunterBars - A module for Bartender2 - by Nevcairiel of Antonidas (EU)
----------------------------------------------------------------------------------

HunterBars switches your Main ActionBar to a melee Bar when you get too close to an enemy to use Auto-Shot.
By default, the Range Bar is the default Bar 1 and the Melee Bar is using Bar 7 ( Bonus Bar )
You can place the spells in the Bonus Bar and hide it afterwards, HunterBars will change the MainBar to the BonusBar
when you are in Melee Range.

You can change the Bar it will change to with /bartender hunter page <number>

For support visit the WoWAce Forums and post in the Bartender2 Thread
http://www.wowace.com/forums/index.php/topic,1837.0.html
