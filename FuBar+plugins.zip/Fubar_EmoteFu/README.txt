FuBar - EmoteFu v0.1.5

Author: Cilraaz (cilraaz@gmail.com)
Release Date: 09-02-2006
TOC Version: 11200

Allows you to easily access emotes, saving the time and hassle of memorizing the emote commands!  Ported from TitanEmoteMenu by Dsanai of Whisperwind.

TO INSTALL: Put the FuBar_EmoteFu folder into
	\World of Warcraft\Interface\AddOns\