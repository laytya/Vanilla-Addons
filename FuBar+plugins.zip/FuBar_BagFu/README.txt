FuBar - BagFu v2

Current Author: phyber (phyber@irc.freenode.net/#wowace)
Original Author: ckknight (ckknight@gmail.com)

Keeps track of space left in your bags.

TO INSTALL: Put the FuBar_BagFu folder into
	\World of Warcraft\Interface\AddOns\
