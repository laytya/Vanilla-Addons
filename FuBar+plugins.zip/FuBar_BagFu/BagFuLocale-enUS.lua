local L = AceLibrary("AceLocale-2.2"):new("FuBar_BagFu")

L:RegisterTranslations("enUS", function() return {
	["Ammo/Soul Bags"] = true,
	["Profession Bags"] = true,
	["Bag Depletion"] = true,
	["Include ammo/soul bags"] = true,
	["Include profession bags"] = true,
	["Show depletion of bags"] = true,
	["Bag Total"] = true,
	["Show total amount of space in bags"] = true,


	["Soul Bag"] = true,
	["Enchanting Bag"] = true,
	["Herb Bag"] = true,
	["Engineering Bag"] = true,
	["Quiver"] = true,
	["Ammo Pouch"] = true,

	["Click to open your bags"] = true
} end)
