From A View To A Kill Fu BETA
-----------------------------




Author: neolith

This is a plugin to ckknight's FuBar2.
It allows the raidleader to set dynamic RaidTargetIcons.

- What does that mean?
If you are the leader of a raid, this plugin allows you to assign RaidTargetIcons to always appear on targets of specified players.
Once one of those players changes their target, the RTI will also change. If they lose their target, the RTI will vanish.
Only the raidleader needs to have this plugin.

- Why did I code that?
Our raid had problems with Nefarian phase 1. Even though our rougues were able to assist players via MTTs they sometimes had problems
to figure out where exactly the mob they were attacking was because there were just to many mobs onscreen. From A View To A Kill Fu solved that problem.
It has also proven quite helpfull in MC where the two MTs can now easily target the giants on their own because of the instant visual feedback.


Right-click to open the menu and set/remove players that will automatically set the RTIs.
Ctrl-leftclick to quickly clear the list.

PLEASE NOTE: I am a graphics guy not a coder - there still might be serious or stupid errors in this addon.

Dependencies:
- FuBar2 (which requires ACE2)

INSTALL
-------
Copy the FuBar_FromAViewToAKillFu folder into "World of Warcraft\Interface\AddOns\"


THANKS
------
to Johannes of EU_Aegwynn for testing this plugin during real raids and giving feedback
to everyone at the wowace forums for their work and help


TO DO
-----
- french localization
- more testing


CHANGES
-------
BETA 15-10-2006
- added quickclear of the list
- moved remaining strings to Locale_enUS.lua
- added Locale_deDE.lua
- removed all unecessary code comments

ALPHA 20-09-2006
- first working version